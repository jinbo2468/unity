# EmojiText
Advance Unity Text，Support Icon、Emoji、Hyperlink、Button

blog:https://blog.csdn.net/lahmiley/article/details/83759753
